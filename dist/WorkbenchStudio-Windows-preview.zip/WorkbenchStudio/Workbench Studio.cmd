@echo off
set "PYTHONDONTWRITEBYTECODE=1"
start "" /D "%~dp0" "%~dp0Workbench Studio.exe" %*
